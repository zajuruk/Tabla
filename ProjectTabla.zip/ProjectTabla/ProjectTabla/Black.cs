﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectTabla
{
    class Black
    {
         public int rad { get; set; }
        public int x { get; set; }
        public int y { get; set; }


        public Black() { }
        
        public Black(int rad, int x, int y) {

            this.rad = rad;
            this.x = x;
            this.y = y;
        }
    }
}
