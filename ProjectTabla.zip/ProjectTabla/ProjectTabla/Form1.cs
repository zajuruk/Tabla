﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProjectTabla
{
    public partial class Form1 : Form
    {

        Graphics g;
        

        public Form1()
        {
            InitializeComponent();
        }

       

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {
            g = e.Graphics;
            //zelena pozadina
            Rectangle rex = new Rectangle(0, 0, panel1.Width,panel1.Height);
            g.FillRectangle(Brushes.Green, rex);

            //border
            Rectangle rec = new Rectangle(20, 20, panel1.Width -40, panel1.Height - 40);
            g.DrawRectangle(new Pen(Brushes.Brown , 20), rec);

            //fil
            rex = new Rectangle(20, 20, panel1.Width - 40, panel1.Height - 40);
            g.FillRectangle(Brushes.Beige, rex);

            //mid or feed
            Pen pnr = new Pen(Brushes.Brown,80);
            Point x= new Point(panel1.Width/2,20);
            Point y= new Point(panel1.Width/2,panel1.Height -20);
            g.DrawLine(pnr, x,y);

            //pac na mid or feed
            
            rec = new Rectangle(panel1.Width/2 - 30,40,60,60);            
            g.FillEllipse(Brushes.White, rec);
            g.DrawEllipse(new Pen(Brushes.Black,2),rec);
                           
            
            //g.DrawImage(img, 0, 0);
            rec = new Rectangle(panel1.Width / 2 - 30, panel1.Height - 110, 60, 60); 
            g.FillEllipse(Brushes.Black, rec);
            g.DrawEllipse(new Pen(Brushes.White,2),rec);

            for (int i = 0; i < panel1.Width; i+=170) {
                Row ro = new Row(i, 0, "black");
                ro.draw(e.Graphics);
            }



                Invalidate();
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Dispose();
        }
    }
}
