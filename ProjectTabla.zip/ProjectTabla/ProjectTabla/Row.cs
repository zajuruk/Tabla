﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace ProjectTabla
{
    public class Row
    {
        public Point[] point;
        public int width;
        public int height;
        public string color;
        public int x;
        public int y;

        public Row(int x, int y,string color) {
            point = new Point[3];
            //point[0] = a;
            //point[1] = b;
            //point[2] = c;
            this.color = color;
            this.width = 150;
            this.height = 200;
            
        }

        public void draw(Graphics g) {


            if (color == "black")
            {
                g.FillPolygon(Brushes.Black, point);
            }
            else if (color == "white") {
                g.FillPolygon(Brushes.Black, point);
            }

            
 
        }
    }
}
